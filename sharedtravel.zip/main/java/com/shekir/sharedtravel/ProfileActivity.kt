package com.shekir.sharedtravel

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarProfile)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val etName = findViewById<TextInputEditText>(R.id.etProfileName)
        val etEmail = findViewById<TextInputEditText>(R.id.etProfileEmail)
        val etPhone = findViewById<TextInputEditText>(R.id.etProfilePhone)
        val btnUpdate = findViewById<MaterialButton>(R.id.btnUpdateProfile)
        val btnChangePassword = findViewById<MaterialButton>(R.id.btnChangePassword)
        val progressBar = findViewById<ProgressBar>(R.id.progressBarProfile)

        loadUserData(etName, etEmail, etPhone)

        btnUpdate.setOnClickListener {
            val newName = etName.text.toString().trim()
            val newPhone = etPhone.text.toString().trim()

            if (newName.isEmpty() || newPhone.isEmpty()) {
                Toast.makeText(this, getString(R.string.name_error_empty), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            updateProfile(newName, newPhone, progressBar)
        }

        btnChangePassword.setOnClickListener {
            sendPasswordReset()
        }
    }

    private fun loadUserData(etName: TextInputEditText, etEmail: TextInputEditText, etPhone: TextInputEditText) {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    etName.setText(document.getString("name"))
                    etEmail.setText(document.getString("email"))
                    etPhone.setText(document.getString("phone"))
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading profile", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateProfile(name: String, phone: String, progressBar: ProgressBar) {
        val userId = auth.currentUser?.uid ?: return
        progressBar.visibility = View.VISIBLE

        val updates = hashMapOf<String, Any>(
            "name" to name,
            "phone" to phone
        )

        db.collection("users").document(userId).update(updates)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                Toast.makeText(this, getString(R.string.profile_updated), Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                progressBar.visibility = View.GONE
                Toast.makeText(this, getString(R.string.profile_update_error), Toast.LENGTH_SHORT).show()
            }
    }

    private fun sendPasswordReset() {
        val email = auth.currentUser?.email
        if (email != null) {
            auth.sendPasswordResetEmail(email)
                .addOnSuccessListener {
                    Toast.makeText(this, getString(R.string.password_reset_sent), Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, getString(R.string.password_reset_error), Toast.LENGTH_SHORT).show()
                }
        }
    }
}
