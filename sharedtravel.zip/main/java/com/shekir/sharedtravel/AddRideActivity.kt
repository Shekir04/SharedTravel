package com.shekir.sharedtravel

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Calendar
import java.util.Locale

class AddRideActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private val departureCalendar = Calendar.getInstance()
    private var editingRideId: String? = null
    private var originalCreatedAt: Long = 0L
    private var startLat: Double? = null
    private var startLng: Double? = null
    private var endLat: Double? = null
    private var endLng: Double? = null
    private var ride: Ride? = null

    // Views
    private lateinit var etDriverName: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var etFromCity: TextInputEditText
    private lateinit var etToCity: TextInputEditText
    private lateinit var etDepartureDate: TextInputEditText
    private lateinit var etDepartureTime: TextInputEditText
    private lateinit var etPrice: TextInputEditText
    private lateinit var etSeats: TextInputEditText

    private lateinit var tilDriverName: TextInputLayout
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPhone: TextInputLayout
    private lateinit var tilFromCity: TextInputLayout
    private lateinit var tilToCity: TextInputLayout
    private lateinit var tilDepartureDate: TextInputLayout
    private lateinit var tilDepartureTime: TextInputLayout
    private lateinit var tilPrice: TextInputLayout
    private lateinit var tilSeats: TextInputLayout

    private lateinit var tvCalculatedArrivalTime: TextView
    private lateinit var btnPublish: MaterialButton
    private lateinit var progressBar: ProgressBar

    // Activity Result Launchers
    private val startLocationLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            startLat = data?.getDoubleExtra("EXTRA_LAT", 0.0)
            startLng = data?.getDoubleExtra("EXTRA_LNG", 0.0)
            val cityName = data?.getStringExtra("EXTRA_CITY_NAME")
            if (!cityName.isNullOrEmpty()) etFromCity.setText(cityName)
        }
    }

    private val endLocationLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            endLat = data?.getDoubleExtra("EXTRA_LAT", 0.0)
            endLng = data?.getDoubleExtra("EXTRA_LNG", 0.0)
            val cityName = data?.getStringExtra("EXTRA_CITY_NAME")
            if (!cityName.isNullOrEmpty()) etToCity.setText(cityName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_ride)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        initViews()
        setupToolbar()
        loadInitialData()
        setupListeners()
    }

    private fun initViews() {
        tilDriverName = findViewById(R.id.tilDriverName)
        tilEmail = findViewById(R.id.tilEmail)
        tilPhone = findViewById(R.id.tilPhone)
        tilFromCity = findViewById(R.id.tilFromCity)
        tilToCity = findViewById(R.id.tilToCity)
        tilDepartureDate = findViewById(R.id.tilDepartureDate)
        tilDepartureTime = findViewById(R.id.tilDepartureTime)
        tilPrice = findViewById(R.id.tilPrice)
        tilSeats = findViewById(R.id.tilSeats)

        etDriverName = findViewById(R.id.etDriverName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etFromCity = findViewById(R.id.etFromCity)
        etToCity = findViewById(R.id.etToCity)
        etDepartureDate = findViewById(R.id.etDepartureDate)
        etDepartureTime = findViewById(R.id.etDepartureTime)
        etPrice = findViewById(R.id.etPrice)
        etSeats = findViewById(R.id.etSeats)

        tvCalculatedArrivalTime = findViewById(R.id.tvCalculatedArrivalTime)
        btnPublish = findViewById(R.id.btnPublish)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun loadInitialData() {
        ride = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("EXTRA_RIDE", Ride::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("EXTRA_RIDE") as? Ride
        }

        ride?.let { currentRide ->
            editingRideId = currentRide.id
            originalCreatedAt = currentRide.createdAt
            supportActionBar?.title = getString(R.string.edit_ride)
            btnPublish.text = getString(R.string.update_ride)

            etDriverName.setText(currentRide.driverName)
            etEmail.setText(currentRide.email)
            etPhone.setText(currentRide.phone)
            etFromCity.setText(currentRide.fromCity)
            etToCity.setText(currentRide.toCity)
            etDepartureDate.setText(currentRide.departureDate)
            etDepartureTime.setText(currentRide.departureTime)
            etPrice.setText(currentRide.price)
            etSeats.setText(currentRide.availableSeats.toString())

            startLat = currentRide.startLat
            startLng = currentRide.startLng
            endLat = currentRide.endLat
            endLng = currentRide.endLng

            departureCalendar.timeInMillis = currentRide.departureTimestamp
            updateArrivalTime()
        } ?: loadUserProfile()
    }

    private fun setupListeners() {
        findViewById<CheckBox>(R.id.cbAnonymous).setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                etDriverName.setText(getString(R.string.anonymous))
                etDriverName.isEnabled = false
                tilDriverName.error = null
                tilDriverName.isErrorEnabled = false
            } else {
                etDriverName.isEnabled = true
                loadUserProfile()
            }
        }

        findViewById<BottomNavigationView>(R.id.bottomNavigationAdd).apply {
            selectedItemId = R.id.nav_add
            setOnItemSelectedListener { item ->
                when (item.itemId) {
                    R.id.nav_home -> {
                        startActivity(Intent(this@AddRideActivity, RidesActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        })
                        finish()
                        true
                    }
                    R.id.nav_add -> true
                    R.id.nav_saved -> {
                        startActivity(Intent(this@AddRideActivity, SavedRidesActivity::class.java))
                        finish()
                        true
                    }
                    R.id.nav_settings -> {
                        startActivity(Intent(this@AddRideActivity, SettingsActivity::class.java))
                        finish()
                        true
                    }
                    else -> false
                }
            }
        }

        etDepartureDate.setOnClickListener { showDatePicker() }
        etDepartureTime.setOnClickListener { showTimePicker() }

        val cityTextWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { updateArrivalTime() }
        }
        
        etFromCity.addTextChangedListener(cityTextWatcher)
        etToCity.addTextChangedListener(cityTextWatcher)

        setupErrorClearing(tilDriverName, etDriverName)
        setupErrorClearing(tilEmail, etEmail)
        setupErrorClearing(tilPhone, etPhone)
        setupErrorClearing(tilFromCity, etFromCity)
        setupErrorClearing(tilToCity, etToCity)
        setupErrorClearing(tilPrice, etPrice)
        setupErrorClearing(tilSeats, etSeats)

        findViewById<MaterialButton>(R.id.btnSelectStartOnMap).setOnClickListener {
            startLocationLauncher.launch(Intent(this, LocationPickerActivity::class.java).apply {
                putExtra("EXTRA_TITLE", getString(R.string.start_point))
                putExtra("EXTRA_CITY", etFromCity.text.toString())
            })
        }

        findViewById<MaterialButton>(R.id.btnSelectEndOnMap).setOnClickListener {
            endLocationLauncher.launch(Intent(this, LocationPickerActivity::class.java).apply {
                putExtra("EXTRA_TITLE", getString(R.string.end_point))
                putExtra("EXTRA_CITY", etToCity.text.toString())
            })
        }

        btnPublish.setOnClickListener { if (validateForm()) publishRide() }
    }

    private fun showDatePicker() {
        DatePickerDialog(this, { _, year, month, day ->
            departureCalendar.set(Calendar.YEAR, year)
            departureCalendar.set(Calendar.MONTH, month)
            departureCalendar.set(Calendar.DAY_OF_MONTH, day)
            etDepartureDate.setText(String.format(Locale.getDefault(), "%02d/%02d/%04d", day, month + 1, year))
            tilDepartureDate.error = null
        }, departureCalendar.get(Calendar.YEAR), departureCalendar.get(Calendar.MONTH), departureCalendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showTimePicker() {
        TimePickerDialog(this, { _, hour, minute ->
            departureCalendar.set(Calendar.HOUR_OF_DAY, hour)
            departureCalendar.set(Calendar.MINUTE, minute)
            etDepartureTime.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute))
            tilDepartureTime.error = null
            updateArrivalTime()
        }, departureCalendar.get(Calendar.HOUR_OF_DAY), departureCalendar.get(Calendar.MINUTE), true).show()
    }

    private fun setupErrorClearing(til: TextInputLayout, et: TextInputEditText) {
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                til.error = null
                til.isErrorEnabled = false
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadUserProfile() {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).get().addOnSuccessListener { document ->
            if (document != null && document.exists()) {
                if (etDriverName.isEnabled) etDriverName.setText(document.getString("name") ?: "")
                etEmail.setText(document.getString("email") ?: "")
                etPhone.setText(document.getString("phone") ?: "")
            }
        }
    }

    private fun updateArrivalTime() {
        if (etDepartureTime.text.isNullOrBlank()) return
        val from = etFromCity.text.toString().trim().lowercase()
        val to = etToCity.text.toString().trim().lowercase()

        val durationMinutes = when {
            isMatch(from, to, "sofia", "plovdiv") || isMatch(from, to, "софия", "пловдив") -> 90
            isMatch(from, to, "sofia", "varna") || isMatch(from, to, "софия", "варна") -> 300
            isMatch(from, to, "sofia", "burgas") || isMatch(from, to, "софия", "бургас") -> 240
            isMatch(from, to, "sofia", "stara zagora") || isMatch(from, to, "софия", "стара загора") -> 150
            isMatch(from, to, "plovdiv", "burgas") || isMatch(from, to, "пловдив", "бургас") -> 150
            isMatch(from, to, "sofia", "ruse") || isMatch(from, to, "софия", "русе") -> 210
            isMatch(from, to, "sofia", "veliko tarnovo") || isMatch(from, to, "софия", "велико търново") -> 180
            from.isNotEmpty() && to.isNotEmpty() -> 150
            else -> return
        }

        val arrivalCalendar = departureCalendar.clone() as Calendar
        arrivalCalendar.add(Calendar.MINUTE, durationMinutes)
        val arrivalTime = String.format(Locale.getDefault(), "%02d:%02d", arrivalCalendar.get(Calendar.HOUR_OF_DAY), arrivalCalendar.get(Calendar.MINUTE))

        tvCalculatedArrivalTime.text = String.format(getString(R.string.arrival_time_display_format), arrivalTime)
        tvCalculatedArrivalTime.visibility = View.VISIBLE
        tvCalculatedArrivalTime.tag = arrivalTime
    }

    private fun isMatch(from: String, to: String, c1: String, c2: String) = (from == c1 && to == c2) || (from == c2 && to == c1)

    private fun validateForm(): Boolean {
        var isValid = true
        fun setError(til: TextInputLayout, resId: Int) { til.error = getString(resId); isValid = false }

        if (etDriverName.text.isNullOrBlank()) setError(tilDriverName, R.string.error_enter_name)
        if (etEmail.text.isNullOrBlank()) setError(tilEmail, R.string.error_enter_email)
        else if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.text.toString()).matches()) setError(tilEmail, R.string.email_error_invalid)
        
        if (etPhone.text.isNullOrBlank()) setError(tilPhone, R.string.error_enter_phone)
        if (etFromCity.text.isNullOrBlank()) setError(tilFromCity, R.string.error_enter_from_city)
        if (etToCity.text.isNullOrBlank()) setError(tilToCity, R.string.error_enter_to_city)
        if (etDepartureDate.text.isNullOrBlank()) setError(tilDepartureDate, R.string.error_enter_departure_date)
        if (etDepartureTime.text.isNullOrBlank()) setError(tilDepartureTime, R.string.error_enter_departure_time)
        if (etPrice.text.isNullOrBlank()) setError(tilPrice, R.string.error_enter_price)
        if (etSeats.text.isNullOrBlank()) setError(tilSeats, R.string.error_enter_seats)

        if (isValid && tvCalculatedArrivalTime.text.isNullOrBlank()) {
            updateArrivalTime()
            if (tvCalculatedArrivalTime.text.isNullOrBlank()) {
                isValid = false
                Toast.makeText(this, R.string.error_enter_arrival_time, Toast.LENGTH_SHORT).show()
            }
        }
        return isValid
    }

    private fun publishRide() {
        btnPublish.isEnabled = false
        progressBar.visibility = View.VISIBLE

        // Get current user currency for the ride
        val sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)
        val userCurrency = sharedPref.getString("My_Currency", "EUR") ?: "EUR"

        val rideData = hashMapOf(
            "driverName" to etDriverName.text.toString(),
            "email" to etEmail.text.toString(),
            "phone" to etPhone.text.toString(),
            "fromCity" to etFromCity.text.toString(),
            "toCity" to etToCity.text.toString(),
            "departureDate" to etDepartureDate.text.toString(),
            "departureTime" to etDepartureTime.text.toString(),
            "arrivalTime" to (tvCalculatedArrivalTime.tag?.toString() ?: ""),
            "price" to etPrice.text.toString(),
            "currency" to (ride?.currency ?: userCurrency),
            "availableSeats" to (etSeats.text.toString().toIntOrNull() ?: 0),
            "bookedUsers" to (ride?.bookedUsers ?: emptyList()),
            "userId" to auth.currentUser?.uid,
            "departureTimestamp" to departureCalendar.timeInMillis,
            "createdAt" to if (editingRideId != null) originalCreatedAt else System.currentTimeMillis(),
            "startLat" to startLat, "startLng" to startLng, "endLat" to endLat, "endLng" to endLng
        )

        val task = if (editingRideId != null) db.collection("rides").document(editingRideId!!).set(rideData)
                   else db.collection("rides").add(rideData)

        task.addOnSuccessListener {
            Toast.makeText(this, if (editingRideId != null) R.string.ride_updated_success else R.string.ride_published_success, Toast.LENGTH_SHORT).show()
            finish()
        }.addOnFailureListener { e ->
            btnPublish.isEnabled = true
            progressBar.visibility = View.GONE
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add_ride, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_saved_rides -> { startActivity(Intent(this, SavedRidesActivity::class.java)); true }
            R.id.action_booked_rides -> {
                startActivity(Intent(this, MyRidesActivity::class.java).apply { putExtra("SHOW_BOOKED", true) })
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
