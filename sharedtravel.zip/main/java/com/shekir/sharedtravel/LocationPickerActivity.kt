package com.shekir.sharedtravel

import android.app.Activity
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class LocationPickerActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var initialCity: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_picker)

        initialCity = intent.getStringExtra("EXTRA_CITY")
        val title = intent.getStringExtra("EXTRA_TITLE") ?: getString(R.string.select_on_map)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = title
        toolbar.setNavigationOnClickListener { finish() }

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        findViewById<MaterialButton>(R.id.btnConfirmLocation).setOnClickListener {
            val center = mMap.cameraPosition.target
            
            lifecycleScope.launch {
                val intent = Intent()
                intent.putExtra("EXTRA_LAT", center.latitude)
                intent.putExtra("EXTRA_LNG", center.longitude)

                // Try to get address/city name from coordinates in background
                val cityName = withContext(Dispatchers.IO) {
                    try {
                        val geocoder = Geocoder(this@LocationPickerActivity, Locale.getDefault())
                        val addresses = geocoder.getFromLocation(center.latitude, center.longitude, 1)
                        if (!addresses.isNullOrEmpty()) {
                            addresses[0].locality ?: addresses[0].subAdminArea ?: ""
                        } else ""
                    } catch (e: Exception) {
                        e.printStackTrace()
                        ""
                    }
                }
                
                if (cityName.isNotEmpty()) {
                    intent.putExtra("EXTRA_CITY_NAME", cityName)
                }

                setResult(Activity.RESULT_OK, intent)
                finish()
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        
        // Default to Bulgaria center
        val defaultLocation = LatLng(42.7339, 25.4858)
        val defaultZoom = 7f

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, defaultZoom))

        // If a city was provided, try to move there
        initialCity?.let { city ->
            lifecycleScope.launch {
                val cityLatLng = withContext(Dispatchers.IO) {
                    try {
                        val geocoder = Geocoder(this@LocationPickerActivity, Locale.getDefault())
                        val addresses = geocoder.getFromLocationName("$city, Bulgaria", 1)
                        if (!addresses.isNullOrEmpty()) {
                            LatLng(addresses[0].latitude, addresses[0].longitude)
                        } else null
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                
                cityLatLng?.let {
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(it, 13f))
                }
            }
        }
    }
}
