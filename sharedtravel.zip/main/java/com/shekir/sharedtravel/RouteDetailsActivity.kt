package com.shekir.sharedtravel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RouteDetailsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var currentRide: Ride? = null
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_route_details)

        currentRide = intent.getSerializableExtra("EXTRA_RIDE") as? Ride
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupUI()
    }

    private fun setupUI() {
        val ride = currentRide ?: return

        findViewById<TextView>(R.id.tvRouteTitle).text = "${ride.fromCity} ➔ ${ride.toCity}"
        findViewById<TextView>(R.id.tvDepartureDate).text = "${getString(R.string.departure_date)}: ${ride.departureDate}"
        findViewById<TextView>(R.id.tvDepartureTime).text = "${getString(R.string.departure_label)}: ${ride.departureTime}"
        findViewById<TextView>(R.id.tvArrivalTime).text = "${getString(R.string.arrival_label)}: ${ride.arrivalTime}"
        findViewById<TextView>(R.id.tvTravelDuration).text = getString(R.string.travel_duration)

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val creationDate = sdf.format(Date(ride.createdAt))
        findViewById<TextView>(R.id.tvCreatedAt).text = "${getString(R.string.created_at_label)}: $creationDate"

        val tvPrice = findViewById<TextView>(R.id.tvPrice)
        // Currency conversion logic
        val sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)
        val userCurrency = sharedPref.getString("My_Currency", "EUR") ?: "EUR"
        val ridePrice = ride.price.toDoubleOrNull() ?: 0.0
        val conversionRate = 1.95583

        val (displayPrice, displaySymbol) = when {
            userCurrency == ride.currency -> ridePrice to (if (userCurrency == "EUR") "€" else "лв")
            userCurrency == "BGN" && ride.currency == "EUR" -> (ridePrice * conversionRate) to "лв"
            userCurrency == "EUR" && ride.currency == "BGN" -> (ridePrice / conversionRate) to "€"
            else -> ridePrice to (if (ride.currency == "EUR") "€" else "лв")
        }
        tvPrice.text = "${getString(R.string.price)}: ${String.format(Locale.US, "%.2f %s", displayPrice, displaySymbol)}"

        findViewById<MaterialButton>(R.id.btnCallDriver).setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:${ride.phone}")
            startActivity(intent)
        }

        findViewById<MaterialButton>(R.id.btnNavigate).setOnClickListener {
            val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=${ride.fromCity},Bulgaria&destination=${ride.toCity},Bulgaria")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }

        val llOwnerActions = findViewById<View>(R.id.llOwnerActions)
        val btnEditRide = findViewById<MaterialButton>(R.id.btnEditRide)
        val btnDeleteRide = findViewById<MaterialButton>(R.id.btnDeleteRide)
        val btnBook = findViewById<MaterialButton>(R.id.btnBook)
        val tvSeats = findViewById<TextView>(R.id.tvSeats)
        val btnSave = findViewById<MaterialButton>(R.id.btnSave)

        val currentUserId = auth.currentUser?.uid
        var isBooked = ride.bookedUsers.contains(currentUserId)
        var availableSeats = ride.availableSeats

        fun updateSaveButtonUI() {
            val sharedPref = getSharedPreferences("SavedRides", MODE_PRIVATE)
            val savedIds = sharedPref.getStringSet("ids", emptySet()) ?: emptySet()
            val isSaved = savedIds.contains(ride.id)
            btnSave.setIconResource(if (isSaved) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
        }

        updateSaveButtonUI()

        btnSave.setOnClickListener {
            toggleSaveRide()
            updateSaveButtonUI()
        }

        fun updateBookingUI() {
            tvSeats.text = "${getString(R.string.seats_label)}: $availableSeats"

            if (isBooked) {
                btnBook.text = getString(R.string.status_booked)
                btnBook.setIconResource(android.R.drawable.ic_menu_delete)
            } else {
                btnBook.text = getString(R.string.action_book)
                btnBook.setIconResource(android.R.drawable.ic_input_add)
            }

            if (ride.userId == currentUserId) {
                btnBook.isEnabled = false
                btnBook.alpha = 0.5f
            } else {
                btnBook.isEnabled = isBooked || availableSeats > 0
                btnBook.alpha = 1.0f
            }
        }

        updateBookingUI()

        btnBook.setOnClickListener {
            if (currentUserId == null) return@setOnClickListener
            
            val rideRef = db.collection("rides").document(ride.id)
            db.runTransaction { transaction ->
                val snapshot = transaction.get(rideRef)
                val dbSeats = snapshot.getLong("availableSeats") ?: 0
                val dbBookedUsers = snapshot.get("bookedUsers") as? MutableList<String> ?: mutableListOf()

                if (dbBookedUsers.contains(currentUserId)) {
                    dbBookedUsers.remove(currentUserId)
                    transaction.update(rideRef, "availableSeats", dbSeats + 1)
                    transaction.update(rideRef, "bookedUsers", dbBookedUsers)
                    isBooked = false
                    availableSeats = (dbSeats + 1).toInt()
                } else {
                    if (dbSeats > 0) {
                        dbBookedUsers.add(currentUserId)
                        transaction.update(rideRef, "availableSeats", dbSeats - 1)
                        transaction.update(rideRef, "bookedUsers", dbBookedUsers)
                        isBooked = true
                        availableSeats = (dbSeats - 1).toInt()
                    } else {
                        throw Exception("No seats available")
                    }
                }
            }.addOnSuccessListener {
                updateBookingUI()
                Toast.makeText(this, if (isBooked) getString(R.string.booking_success) else getString(R.string.booking_cancelled), Toast.LENGTH_SHORT).show()
            }.addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        if (ride.userId == auth.currentUser?.uid) {
            llOwnerActions.visibility = View.VISIBLE
            btnDeleteRide.setOnClickListener {
                showDeleteConfirmationDialog(ride.id)
            }
            btnEditRide.setOnClickListener {
                val intent = Intent(this, AddRideActivity::class.java)
                intent.putExtra("EXTRA_RIDE", ride)
                startActivity(intent)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                toggleSaveRide()
                true
            }
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleSaveRide() {
        val ride = currentRide ?: return
        val sharedPref = getSharedPreferences("SavedRides", MODE_PRIVATE)
        val savedIds = sharedPref.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()

        if (savedIds.contains(ride.id)) {
            savedIds.remove(ride.id)
            Toast.makeText(this, getString(R.string.ride_removed), Toast.LENGTH_SHORT).show()
        } else {
            savedIds.add(ride.id)
            Toast.makeText(this, getString(R.string.ride_saved), Toast.LENGTH_SHORT).show()
        }

        sharedPref.edit {
            putStringSet("ids", savedIds)
        }
        invalidateOptionsMenu()
    }

    private fun showDeleteConfirmationDialog(rideId: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_ride)
            .setMessage(R.string.delete_ride_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                deleteRide(rideId)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteRide(rideId: String) {
        db.collection("rides").document(rideId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, R.string.ride_deleted_success, Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        findViewById<ProgressBar>(R.id.progressBarMap).visibility = View.GONE

        val ride = currentRide ?: return

        val startLatLng = if (ride.startLat != null && ride.startLng != null) {
            LatLng(ride.startLat, ride.startLng)
        } else {
            null
        }

        val endLatLng = if (ride.endLat != null && ride.endLng != null) {
            LatLng(ride.endLat, ride.endLng)
        } else {
            null
        }

        if (startLatLng != null && endLatLng != null) {
            mMap.addMarker(MarkerOptions().position(startLatLng).title(getString(R.string.start_point) + ": " + ride.fromCity))
            mMap.addMarker(MarkerOptions().position(endLatLng).title(getString(R.string.end_point) + ": " + ride.toCity))

            val bounds = com.google.android.gms.maps.model.LatLngBounds.Builder()
                .include(startLatLng)
                .include(endLatLng)
                .build()

            mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
        } else {
            val defaultLocation = LatLng(42.6977, 23.3219) // Sofia
            mMap.addMarker(MarkerOptions().position(defaultLocation).title(ride.fromCity))
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 7f))
        }
    }
}
