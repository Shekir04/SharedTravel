package com.shekir.sharedtravel

import java.io.Serializable

data class Ride(
    val id: String,
    val fromCity: String,
    val toCity: String,
    val price: String,
    val currency: String = "EUR", // New field for original currency
    val departureTime: String,
    val arrivalTime: String,
    val driverName: String,
    val phone: String,
    val email: String,
    var availableSeats: Int, // Changed to var for easier local updates
    var bookedUsers: List<String> = emptyList(), // Changed to var for easier local updates
    val userId: String = "",
    val departureTimestamp: Long = 0L,
    val departureDate: String = "",
    val createdAt: Long = 0L,
    val startLat: Double? = null,
    val startLng: Double? = null,
    val endLat: Double? = null,
    val endLng: Double? = null
) : Serializable
