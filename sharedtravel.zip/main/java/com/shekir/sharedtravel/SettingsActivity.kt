package com.shekir.sharedtravel

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarSettings)
        val btnChangeLanguage = findViewById<LinearLayout>(R.id.btnChangeLanguage)
        val btnChangeCurrency = findViewById<LinearLayout>(R.id.btnChangeCurrency)
        val tvCurrentCurrency = findViewById<TextView>(R.id.tvCurrentCurrency)
        val btnMyRides = findViewById<LinearLayout>(R.id.btnMyRides)
        val btnBookedRides = findViewById<LinearLayout>(R.id.btnBookedRides)
        val btnPastRides = findViewById<LinearLayout>(R.id.btnPastRides)
        val btnProfile = findViewById<LinearLayout>(R.id.btnProfile)
        val btnLogout = findViewById<MaterialButton>(R.id.btnLogout)
        val bottomNavigation = findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigationSettings)

        // Load current currency
        val sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)
        val currentCurrency = sharedPref.getString("My_Currency", "EUR") ?: "EUR"
        tvCurrentCurrency.text = if (currentCurrency == "EUR") getString(R.string.currency_euro) else getString(R.string.currency_bgn)

        toolbar.setNavigationOnClickListener {
            finish()
        }

        btnChangeLanguage.setOnClickListener {
            showLanguageDialog()
        }

        btnChangeCurrency.setOnClickListener {
            showCurrencyDialog()
        }

        btnMyRides.setOnClickListener {
            startActivity(Intent(this, MyRidesActivity::class.java))
        }

        btnBookedRides.setOnClickListener {
            val intent = Intent(this, MyRidesActivity::class.java)
            intent.putExtra("SHOW_BOOKED", true)
            startActivity(intent)
        }

        btnPastRides.setOnClickListener {
            val intent = Intent(this, MyRidesActivity::class.java)
            intent.putExtra("SHOW_PAST", true)
            startActivity(intent)
        }

        btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Bottom Navigation
        bottomNavigation.selectedItemId = R.id.nav_settings
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, RidesActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddRideActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_settings -> {
                    // Already here
                    true
                }
                else -> false
            }
        }
    }

    private fun showLanguageDialog() {
        val languages = arrayOf("English", "Български")
        val languageCodes = arrayOf("en", "bg")

        AlertDialog.Builder(this)
            .setTitle(R.string.language)
            .setItems(languages) { _, which ->
                val languageCode = languageCodes[which]
                val appLocale: LocaleListCompat = LocaleListCompat.forLanguageTags(languageCode)
                AppCompatDelegate.setApplicationLocales(appLocale)

                // Save preference
                val sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)
                with(sharedPref.edit()) {
                    putString("My_Lang", languageCode)
                    apply()
                }
            }
            .show()
    }

    private fun showCurrencyDialog() {
        val currencies = arrayOf(getString(R.string.currency_euro), getString(R.string.currency_bgn))
        val currencyCodes = arrayOf("EUR", "BGN")

        AlertDialog.Builder(this)
            .setTitle(R.string.select_currency)
            .setItems(currencies) { _, which ->
                val currencyCode = currencyCodes[which]
                val sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)
                with(sharedPref.edit()) {
                    putString("My_Currency", currencyCode)
                    apply()
                }
                findViewById<TextView>(R.id.tvCurrentCurrency).text = currencies[which]
                Toast.makeText(this, R.string.profile_updated, Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
