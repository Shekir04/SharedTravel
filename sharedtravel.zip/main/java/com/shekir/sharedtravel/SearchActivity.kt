package com.shekir.sharedtravel

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class SearchActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val etFrom = findViewById<TextInputEditText>(R.id.etFrom)
        val etTo = findViewById<TextInputEditText>(R.id.etTo)
        val btnSearch = findViewById<MaterialButton>(R.id.btnSearch)
        val btnClear = findViewById<MaterialButton>(R.id.btnClearSearch)
        val btnSwap = findViewById<MaterialButton>(R.id.btnSwap)

        etFrom.postDelayed({
            etFrom.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(etFrom, InputMethodManager.SHOW_IMPLICIT)
        }, 300)

        btnSwap.setOnClickListener {
            val fromText = etFrom.text.toString()
            val toText = etTo.text.toString()
            etFrom.setText(toText)
            etTo.setText(fromText)
        }

        btnSearch.setOnClickListener {
            val from = etFrom.text.toString().trim()
            val to = etTo.text.toString().trim()

            val intent = Intent(this, RidesActivity::class.java).apply {
                putExtra("EXTRA_FROM", from)
                putExtra("EXTRA_TO", to)
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            finish()
        }

        btnClear.setOnClickListener {
            etFrom.text?.clear()
            etTo.text?.clear()
        }
    }
}
