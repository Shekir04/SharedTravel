package com.shekir.sharedtravel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.edit
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class RideAdapter(private var rides: List<Ride>) : RecyclerView.Adapter<RideAdapter.RideViewHolder>() {

    fun updateList(newList: List<Ride>) {
        rides = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RideViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_ride, parent, false)
        return RideViewHolder(view)
    }

    override fun onBindViewHolder(holder: RideViewHolder, position: Int) {
        val ride = rides[position]
        holder.bind(ride)
    }

    override fun getItemCount() = rides.size

    inner class RideViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRoute: TextView = itemView.findViewById(R.id.tvRoute)
        private val tvPrice: TextView = itemView.findViewById(R.id.tvPrice)
        private val tvDeparture: TextView = itemView.findViewById(R.id.tvDeparture)
        private val tvDepartureDate: TextView = itemView.findViewById(R.id.tvDepartureDate)
        private val tvArrival: TextView = itemView.findViewById(R.id.tvArrival)
        private val tvDriverName: TextView = itemView.findViewById(R.id.tvDriverName)
        private val tvPhone: TextView = itemView.findViewById(R.id.tvPhone)
        private val tvEmail: TextView = itemView.findViewById(R.id.tvEmail)
        private val tvSeats: TextView = itemView.findViewById(R.id.tvSeats)
        private val tvCreatedAt: TextView = itemView.findViewById(R.id.tvCreatedAt)

        private val btnCall: MaterialButton = itemView.findViewById(R.id.btnCall)
        private val btnEmail: MaterialButton = itemView.findViewById(R.id.btnEmail)
        private val btnBook: MaterialButton = itemView.findViewById(R.id.btnBook)
        private val btnSave: MaterialButton = itemView.findViewById(R.id.btnSave)
        private val btnShowMap: MaterialButton = itemView.findViewById(R.id.btnShowMap)

        fun bind(ride: Ride) {
            val context = itemView.context

            val savedPref = context.getSharedPreferences("SavedRides", Context.MODE_PRIVATE)
            val savedIds = savedPref.getStringSet("ids", mutableSetOf()) ?: mutableSetOf()
            val isSaved = savedIds.contains(ride.id)

            btnSave.setIconResource(if (isSaved) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)

            btnSave.setOnClickListener {
                val updatedIds = savedPref.getStringSet("ids", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
                if (updatedIds.contains(ride.id)) {
                    updatedIds.remove(ride.id)
                    btnSave.setIconResource(android.R.drawable.btn_star_big_off)
                    Toast.makeText(context, context.getString(R.string.ride_removed), Toast.LENGTH_SHORT).show()
                } else {
                    updatedIds.add(ride.id)
                    btnSave.setIconResource(android.R.drawable.btn_star_big_on)
                    Toast.makeText(context, context.getString(R.string.ride_saved), Toast.LENGTH_SHORT).show()
                }
                savedPref.edit { putStringSet("ids", updatedIds) }
            }

            itemView.setOnClickListener {
                val intent = Intent(context, RouteDetailsActivity::class.java)
                intent.putExtra("EXTRA_RIDE", ride)
                context.startActivity(intent)
            }

            tvRoute.text = "${ride.fromCity} ➔ ${ride.toCity}"

            // Currency conversion logic
            val sharedPref = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)
            val userCurrency = sharedPref.getString("My_Currency", "EUR") ?: "EUR"
            val ridePrice = ride.price.toDoubleOrNull() ?: 0.0
            val conversionRate = 1.95583

            val (displayPrice, displaySymbol) = when {
                userCurrency == ride.currency -> {
                    // No conversion needed if user preference matches ride currency
                    ridePrice to (if (userCurrency == "EUR") "€" else "лв")
                }
                userCurrency == "BGN" && ride.currency == "EUR" -> {
                    // Convert EUR to BGN
                    (ridePrice * conversionRate) to "лв"
                }
                userCurrency == "EUR" && ride.currency == "BGN" -> {
                    // Convert BGN to EUR
                    (ridePrice / conversionRate) to "€"
                }
                else -> ridePrice to (if (ride.currency == "EUR") "€" else "лв")
            }

            tvPrice.text = String.format(java.util.Locale.US, "%.2f %s", displayPrice, displaySymbol)

            tvDeparture.text = "${context.getString(R.string.departure_label)}: ${ride.departureTime}"
            tvDepartureDate.text = "${context.getString(R.string.departure_date)}: ${ride.departureDate}"
            tvArrival.text = "${context.getString(R.string.arrival_label)}: ${ride.arrivalTime}"
            tvDriverName.text = "${context.getString(R.string.driver_label)}: ${ride.driverName}"
            tvPhone.text = "${context.getString(R.string.phone_label)}: ${ride.phone}"
            tvEmail.text = "${context.getString(R.string.email_label)}: ${ride.email}"
            tvSeats.text = "${context.getString(R.string.seats_label)}: ${ride.availableSeats}"

            if (ride.createdAt != 0L) {
                val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
                val dateString = sdf.format(java.util.Date(ride.createdAt))
                tvCreatedAt.text = "${context.getString(R.string.created_at_label)} $dateString"
                tvCreatedAt.visibility = View.VISIBLE
            } else {
                tvCreatedAt.visibility = View.GONE
            }

            // 1. Handle Phone Call
            btnCall.setOnClickListener {
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:${ride.phone}")
                context.startActivity(intent)
            }

            // 2. Handle Email
            btnEmail.setOnClickListener {
                val intent = Intent(Intent.ACTION_SENDTO)
                intent.data = Uri.parse("mailto:${ride.email}")
                val subject = context.getString(R.string.email_subject, ride.fromCity, ride.toCity)
                intent.putExtra(Intent.EXTRA_SUBJECT, subject)
                context.startActivity(intent)
            }

            // 3. Handle Map Route (Opens Google Maps App directly with the route)
            btnShowMap.setOnClickListener {
                val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=${ride.fromCity},Bulgaria&destination=${ride.toCity},Bulgaria")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                } else {
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            }

            // Booking logic
            val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
            if (currentUser == null) {
                btnBook.visibility = View.GONE
                return
            }
            val currentUserId = currentUser.uid
            var isBooked = ride.bookedUsers.contains(currentUserId)
            val currentTime = System.currentTimeMillis()
            val isPast = ride.departureTimestamp < currentTime

            fun updateBookingButton() {
                if (isBooked) {
                    btnBook.text = if (isPast) context.getString(R.string.status_traveled) else context.getString(R.string.status_booked)
                    btnBook.setIconResource(if (isPast) android.R.drawable.checkbox_on_background else android.R.drawable.ic_menu_delete)
                } else {
                    btnBook.text = context.getString(R.string.action_book)
                    btnBook.setIconResource(android.R.drawable.ic_input_add)
                }

                tvSeats.text = "${context.getString(R.string.seats_label)}: ${ride.availableSeats}"

                // Driver cannot book their own ride, and nobody can book/unbook past rides
                if (isPast || ride.userId == currentUserId) {
                    btnBook.isEnabled = false
                    btnBook.alpha = 0.5f
                } else {
                    btnBook.isEnabled = isBooked || ride.availableSeats > 0
                    btnBook.alpha = 1.0f
                }
            }
            
            updateBookingButton()

            btnBook.setOnClickListener {
                if (isPast) return@setOnClickListener
                val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                val rideRef = db.collection("rides").document(ride.id)

                db.runTransaction { transaction ->
                    val snapshot = transaction.get(rideRef)
                    val currentSeats = snapshot.getLong("availableSeats") ?: 0
                    val bookedUsers = snapshot.get("bookedUsers") as? MutableList<String> ?: mutableListOf()

                    if (bookedUsers.contains(currentUserId)) {
                        // Unbook
                        bookedUsers.remove(currentUserId)
                        val newSeats = (currentSeats + 1).toInt()
                        transaction.update(rideRef, "availableSeats", newSeats)
                        transaction.update(rideRef, "bookedUsers", bookedUsers)

                        // Update local object properties (if your Ride class allows or via reflection/copy)
                        // Since Ride is a data class with val, we can't easily change it without refreshing the list.
                        // However, we'll update the UI state variables.
                        isBooked = false
                        newSeats
                    } else {
                        // Book
                        if (currentSeats > 0) {
                            bookedUsers.add(currentUserId)
                            val newSeats = (currentSeats - 1).toInt()
                            transaction.update(rideRef, "availableSeats", newSeats)
                            transaction.update(rideRef, "bookedUsers", bookedUsers)
                            isBooked = true
                            newSeats
                        } else {
                            throw com.google.firebase.FirebaseException("No seats available")
                        }
                    }
                }.addOnSuccessListener { _ ->
                    // Update local object properties directly since they are now 'var'
                    ride.availableSeats = if (isBooked) ride.availableSeats - 1 else ride.availableSeats + 1
                    val currentBooked = ride.bookedUsers.toMutableList()
                    if (isBooked) {
                        if (!currentBooked.contains(currentUserId)) currentBooked.add(currentUserId)
                    } else {
                        currentBooked.remove(currentUserId)
                    }
                    ride.bookedUsers = currentBooked

                    if (isBooked) {
                        NotificationHelper.scheduleReminder(context, ride)
                        Toast.makeText(context, context.getString(R.string.booking_success), Toast.LENGTH_SHORT).show()
                    } else {
                        NotificationHelper.cancelReminder(context, ride.id)
                        Toast.makeText(context, context.getString(R.string.booking_cancelled), Toast.LENGTH_SHORT).show()
                    }
                    updateBookingButton()
                }.addOnFailureListener { e ->
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
