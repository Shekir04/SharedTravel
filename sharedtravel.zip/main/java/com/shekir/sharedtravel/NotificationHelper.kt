package com.shekir.sharedtravel

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class NotificationHelper : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val rideId = intent.getStringExtra("RIDE_ID") ?: return
        val route = intent.getStringExtra("ROUTE") ?: ""
        
        showNotification(context, rideId, route)
    }

    private fun showNotification(context: Context, rideId: String, route: String) {
        val channelId = "travel_reminders"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val channel = NotificationChannel(
                channelId,
                "Travel Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for upcoming rides"
            }
            notificationManager.createNotificationChannel(channel)


        val intent = Intent(context, RouteDetailsActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, rideId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText("Reminder: Your trip $route starts in 1 hour!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(rideId.hashCode(), notification)
    }

    companion object {
        fun scheduleReminder(context: Context, ride: Ride) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, NotificationHelper::class.java).apply {
                putExtra("RIDE_ID", ride.id)
                putExtra("ROUTE", "${ride.fromCity} ➔ ${ride.toCity}")
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context, ride.id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Schedule 1 hour before departure
            val reminderTime = ride.departureTimestamp - (60 * 60 * 1000)
            
            if (reminderTime > System.currentTimeMillis()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent)
                    } else {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent)
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent)
                }
            }
        }

        fun cancelReminder(context: Context, rideId: String) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, NotificationHelper::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context, rideId.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }
}
