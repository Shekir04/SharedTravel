package com.shekir.sharedtravel

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class SavedRidesActivity : AppCompatActivity() {

    private lateinit var adapter: RideAdapter
    private var savedRides = mutableListOf<Ride>()
    private lateinit var db: FirebaseFirestore
    private lateinit var tvEmptyState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved_rides)

        db = FirebaseFirestore.getInstance()

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        val rvRides = findViewById<RecyclerView>(R.id.rvSavedRides)
        tvEmptyState = findViewById<TextView>(R.id.tvEmptyState)
        val bottomNavigation = findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigationSaved)

        adapter = RideAdapter(emptyList())
        rvRides.layoutManager = LinearLayoutManager(this)
        rvRides.adapter = adapter

        loadSavedRides()

        // Bottom Navigation
        bottomNavigation.selectedItemId = R.id.nav_saved
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, RidesActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddRideActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_saved -> true
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun loadSavedRides() {
        val sharedPref = getSharedPreferences("SavedRides", Context.MODE_PRIVATE)
        val savedIds = sharedPref.getStringSet("ids", emptySet()) ?: emptySet()

        if (savedIds.isEmpty()) {
            tvEmptyState.visibility = View.VISIBLE
            adapter.updateList(emptyList())
            return
        }

        // Fetch each saved ride from Firestore
        // Note: For many items, this is inefficient. In a real app, use whereIn or store full data locally.
        // But for simplicity, we'll fetch them.
        
        val ridesList = mutableListOf<Ride>()
        var loadedCount = 0
        
        for (id in savedIds) {
            db.collection("rides").document(id).get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        val ride = Ride(
                            id = doc.id,
                            fromCity = doc.getString("fromCity") ?: "",
                            toCity = doc.getString("toCity") ?: "",
                            price = doc.getString("price") ?: "",
                            currency = doc.getString("currency") ?: "EUR",
                            departureTime = doc.getString("departureTime") ?: "",
                            arrivalTime = doc.getString("arrivalTime") ?: "",
                            driverName = doc.getString("driverName") ?: "",
                            phone = doc.getString("phone") ?: "",
                            email = doc.getString("email") ?: "",
                            availableSeats = doc.getLong("availableSeats")?.toInt() ?: 0,
                            bookedUsers = doc.get("bookedUsers") as? List<String> ?: emptyList(),
                            userId = doc.getString("userId") ?: "",
                            departureTimestamp = doc.getLong("departureTimestamp") ?: 0L,
                            departureDate = doc.getString("departureDate") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L
                        )
                        ridesList.add(ride)
                    }
                    loadedCount++
                    if (loadedCount == savedIds.size) {
                        ridesList.sortBy { it.departureTimestamp }
                        adapter.updateList(ridesList)
                        tvEmptyState.visibility = if (ridesList.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                .addOnFailureListener {
                    loadedCount++
                    if (loadedCount == savedIds.size) {
                        ridesList.sortBy { it.departureTimestamp }
                        adapter.updateList(ridesList)
                        tvEmptyState.visibility = if (ridesList.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
        }
    }
}
