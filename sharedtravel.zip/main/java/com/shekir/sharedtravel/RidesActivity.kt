package com.shekir.sharedtravel

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class RidesActivity : AppCompatActivity() {

    private lateinit var adapter: RideAdapter
    private var allRides = listOf<Ride>()
    private lateinit var db: FirebaseFirestore
    private lateinit var tvEmptyState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rides)

        db = FirebaseFirestore.getInstance()

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val rvRides = findViewById<RecyclerView>(R.id.rvRides)
        tvEmptyState = findViewById<TextView>(R.id.tvEmptyState)
        val bottomNavigation = findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNavigation)

        adapter = RideAdapter(emptyList())
        rvRides.layoutManager = LinearLayoutManager(this)
        rvRides.adapter = adapter

        // Load Data from Firestore
        loadRidesFromFirestore()

        // Handle incoming search intent from SearchActivity
        handleIntent(intent)

        // Bottom Navigation
        bottomNavigation.selectedItemId = R.id.nav_home
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Reset to all rides
                    adapter.updateList(allRides)
                    tvEmptyState.visibility = if (allRides.isEmpty()) View.VISIBLE else View.GONE
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddRideActivity::class.java))
                    true
                }
                R.id.nav_saved -> {
                    val intent = Intent(this, SavedRidesActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        val fromExtra = intent.getStringExtra("EXTRA_FROM")
        val toExtra = intent.getStringExtra("EXTRA_TO")
        
        if (fromExtra != null || toExtra != null) {
            val from = fromExtra?.trim() ?: ""
            val to = toExtra?.trim() ?: ""

            // We use allRides here, but it might not be loaded yet if handleIntent is called from onCreate
            // If it's empty, the snapshot listener will eventually update the list.
            // But we want to filter it immediately if possible.

            val filterRides = {
                val filteredList = allRides.filter {
                    it.fromCity.contains(from, ignoreCase = true) &&
                    it.toCity.contains(to, ignoreCase = true)
                }
                adapter.updateList(filteredList)
                tvEmptyState.visibility = if (filteredList.isEmpty()) View.VISIBLE else View.GONE
            }

            if (allRides.isNotEmpty()) {
                filterRides()
            } else {
                // If data isn't loaded yet, we'll need to store the search params
                // and apply them once data arrives.
                // For simplicity in this step, let's just use a small delay or rely on the fact that
                // typically searches happen after some interaction.
                findViewById<View>(android.R.id.content).postDelayed({
                    filterRides()
                }, 1000)
            }
        }
    }

    private fun loadRidesFromFirestore() {
        db.collection("rides")
            .orderBy("departureTimestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(this, "Error loading rides: ${e.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val currentTime = System.currentTimeMillis()
                    val ridesList = snapshot.documents.mapNotNull { doc ->
                        val ride = Ride(
                            id = doc.id,
                            fromCity = doc.getString("fromCity") ?: "",
                            toCity = doc.getString("toCity") ?: "",
                            price = doc.getString("price") ?: "",
                            currency = doc.getString("currency") ?: "EUR",
                            departureTime = doc.getString("departureTime") ?: "",
                            arrivalTime = doc.getString("arrivalTime") ?: "",
                            driverName = doc.getString("driverName") ?: "",
                            phone = doc.getString("phone") ?: "",
                            email = doc.getString("email") ?: "",
                            availableSeats = doc.getLong("availableSeats")?.toInt() ?: 0,
                            bookedUsers = doc.get("bookedUsers") as? List<String> ?: emptyList(),
                            userId = doc.getString("userId") ?: "",
                            departureTimestamp = doc.getLong("departureTimestamp") ?: 0L,
                            departureDate = doc.getString("departureDate") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L
                        )
                        // Only include rides that haven't departed yet
                        if (ride.departureTimestamp > currentTime) ride else null
                    }
                    allRides = ridesList
                    adapter.updateList(allRides)
                    tvEmptyState.visibility = if (allRides.isEmpty()) View.VISIBLE else View.GONE
                }
            }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add_ride, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> {
                startActivity(Intent(this, SearchActivity::class.java))
                true
            }
            R.id.action_saved_rides -> {
                startActivity(Intent(this, SavedRidesActivity::class.java))
                true
            }
            R.id.action_booked_rides -> {
                val intent = Intent(this, MyRidesActivity::class.java)
                intent.putExtra("SHOW_BOOKED", true)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
