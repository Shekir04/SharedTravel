package com.shekir.sharedtravel

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MyRidesActivity : AppCompatActivity() {

    private lateinit var adapter: RideAdapter
    private lateinit var db: FirebaseFirestore
    private lateinit var tvEmptyState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_rides)

        db = FirebaseFirestore.getInstance()

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarMyRides)
        val rvMyRides = findViewById<RecyclerView>(R.id.rvMyRides)
        tvEmptyState = findViewById<TextView>(R.id.tvMyRidesEmptyState)

        val showBooked = intent.getBooleanExtra("SHOW_BOOKED", false)
        val showPast = intent.getBooleanExtra("SHOW_PAST", false)

        if (showBooked) {
            toolbar.title = getString(R.string.booked_rides)
        } else if (showPast) {
            toolbar.title = getString(R.string.past_rides)
        }

        toolbar.setNavigationOnClickListener {
            finish()
        }

        adapter = RideAdapter(emptyList())
        rvMyRides.layoutManager = LinearLayoutManager(this)
        rvMyRides.adapter = adapter

        loadRides(showBooked, showPast)
    }

    private fun loadRides(showBooked: Boolean, showPast: Boolean) {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val currentTime = System.currentTimeMillis()

        val query = when {
            showPast -> {
                db.collection("rides")
                    .whereArrayContains("bookedUsers", currentUserId)
                    .whereLessThan("departureTimestamp", currentTime)
            }
            showBooked -> {
                db.collection("rides")
                    .whereArrayContains("bookedUsers", currentUserId)
                    .whereGreaterThanOrEqualTo("departureTimestamp", currentTime)
            }
            else -> {
                db.collection("rides")
                    .whereEqualTo("userId", currentUserId)
            }
        }

        query.orderBy("departureTimestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Toast.makeText(this, "Error loading rides: ${e.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val ridesList = snapshot.documents.mapNotNull { doc ->
                        Ride(
                            id = doc.id,
                            fromCity = doc.getString("fromCity") ?: "",
                            toCity = doc.getString("toCity") ?: "",
                            price = doc.getString("price") ?: "",
                            currency = doc.getString("currency") ?: "EUR",
                            departureTime = doc.getString("departureTime") ?: "",
                            arrivalTime = doc.getString("arrivalTime") ?: "",
                            driverName = doc.getString("driverName") ?: "",
                            phone = doc.getString("phone") ?: "",
                            email = doc.getString("email") ?: "",
                            availableSeats = doc.getLong("availableSeats")?.toInt() ?: 0,
                            bookedUsers = doc.get("bookedUsers") as? List<String> ?: emptyList(),
                            userId = doc.getString("userId") ?: "",
                            departureTimestamp = doc.getLong("departureTimestamp") ?: 0L,
                            departureDate = doc.getString("departureDate") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L
                        )
                    }
                    adapter.updateList(ridesList)
                    tvEmptyState.visibility = if (ridesList.isEmpty()) View.VISIBLE else View.GONE
                }
            }
    }
}
